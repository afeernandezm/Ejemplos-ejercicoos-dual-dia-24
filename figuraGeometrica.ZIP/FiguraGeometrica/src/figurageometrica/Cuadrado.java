/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurageometrica;

/**
 *
 * @author formacion15
 */
public class Cuadrado extends Rectangulo {

    private double lado;

    public Cuadrado() {
        System.out.println("cuadrado sin parámetros");
        this.lado = 1;
    }

    public Cuadrado(double lado) {
        System.out.println("cuadrado con parámetros");
        this.lado = lado;
    }

    @Override
    public Double area() {
        System.out.println("cuadrado.area");
        return lado * lado;

    }

}
