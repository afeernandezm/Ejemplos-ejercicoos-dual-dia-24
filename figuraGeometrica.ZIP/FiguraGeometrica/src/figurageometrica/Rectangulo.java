/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurageometrica;

/**
 *
 * @author formacion15
 */
public class Rectangulo extends ClaseAbstracta {

    private double alto;
    private double ancho;
    private Punto punto;

    public Rectangulo() {
        System.out.println("rectángulo sin parámetros");
        this.alto = 1;
        this.ancho = 1.3;
        this.punto = new Punto(0, 0);
    }

    public Rectangulo(double alto, double ancho, Punto punto) {
        super();
        System.out.println("rectángulo constructor con parámetros");
        this.alto = alto;
        this.ancho = ancho;
        this.punto = punto;
    }

    @Override
    public Double area() {
        System.out.println("rectángulo.area");
        return alto*ancho;
       
    }

  
    

}

