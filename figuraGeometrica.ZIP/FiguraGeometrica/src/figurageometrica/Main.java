/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurageometrica;

/**
 *
 * @author formacion15
 */
public class Main {

    public static Figura getFiguraAleatoria() {
        double aleatorio = Math.random() * 10;
        if (aleatorio < 2.5) {
            return new Circulo(new Punto(10, 15), 17d);
        } else if (aleatorio < 5) {
            return new Triangulo();
        } else if (aleatorio < 7.5) {
            return new Rectangulo();
        }
        return new Cuadrado();
    }

    public static void main(String[] args) {
        Punto punto = new Punto(20, 30);
        Circulo circulo = new Circulo();
        Triangulo triangulo = new Triangulo(12.3, 27.1, 96.8, punto);
        Rectangulo rectangulo = new Rectangulo(15, 20, new Punto(5, 10));
        Cuadrado cuadrado = new Cuadrado();
//Ahora probamos con polimorfismo, y como podemos observar podemos meter un
//cuadrado dentro de un rectángulo ya que cuadrado hereda de rectángulo.
        Rectangulo rectangulo2 = new Cuadrado(9);
        System.out.println(rectangulo2.area());
        Figura figura = getFiguraAleatoria();
        System.out.println(figura.area());
        ClaseAbstracta figuraA=new Cuadrado();
    }
}
