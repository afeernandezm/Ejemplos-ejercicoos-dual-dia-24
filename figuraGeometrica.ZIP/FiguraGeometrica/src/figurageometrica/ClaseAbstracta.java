/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurageometrica;

/**
 *
 * @author formacion15
 */
public abstract class ClaseAbstracta implements Figura {

    @Override
    public void pintar() {
        System.out.println("clase abstracta pintar");
    }

    ;
 
    @Override
    public void mover() {
        System.out.println("Clase abstracta mover");
    }
}
