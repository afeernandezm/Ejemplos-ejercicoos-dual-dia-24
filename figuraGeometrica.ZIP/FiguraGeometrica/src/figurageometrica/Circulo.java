/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurageometrica;

/**
 *
 * @author formacion15
 */
public class Circulo extends ClaseAbstracta {

    private Punto punto;
    private double radio;

    public Circulo() {
        this.punto = new Punto(10, 10);
        this.radio = 1d;
    }

    public Circulo(Punto punto, double radio) {
        this.punto = punto;
        this.radio = radio;
    }

    @Override
    public Double area() {
        System.out.println("Círculo, método área");
        return 3.1416 * Math.pow(radio, 2);

    }

  
}

